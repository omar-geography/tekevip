.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static action_bar:I = 0x7f090030

.field public static action_bar_activity_content:I = 0x7f090031

.field public static action_bar_container:I = 0x7f090032

.field public static action_bar_root:I = 0x7f090033

.field public static action_bar_spinner:I = 0x7f090034

.field public static action_bar_subtitle:I = 0x7f090035

.field public static action_bar_title:I = 0x7f090036

.field public static action_context_bar:I = 0x7f090038

.field public static action_menu_divider:I = 0x7f09003b

.field public static action_menu_presenter:I = 0x7f09003c

.field public static action_mode_bar:I = 0x7f09003d

.field public static action_mode_bar_stub:I = 0x7f09003e

.field public static action_mode_close_button:I = 0x7f09003f

.field public static activity_chooser_view_content:I = 0x7f090042

.field public static add:I = 0x7f090043

.field public static alertTitle:I = 0x7f090044

.field public static buttonPanel:I = 0x7f090058

.field public static checkbox:I = 0x7f090061

.field public static checked:I = 0x7f090062

.field public static content:I = 0x7f09006d

.field public static contentPanel:I = 0x7f09006e

.field public static custom:I = 0x7f090074

.field public static customPanel:I = 0x7f090075

.field public static decor_content_parent:I = 0x7f09007a

.field public static default_activity_button:I = 0x7f09007b

.field public static edit_query:I = 0x7f090094

.field public static expand_activities_button:I = 0x7f09009e

.field public static expanded_menu:I = 0x7f09009f

.field public static group_divider:I = 0x7f0900b5

.field public static home:I = 0x7f0900ba

.field public static icon:I = 0x7f0900bd

.field public static image:I = 0x7f0900c2

.field public static listMode:I = 0x7f0900d3

.field public static list_item:I = 0x7f0900d4

.field public static message:I = 0x7f0900ee

.field public static multiply:I = 0x7f09010f

.field public static none:I = 0x7f090119

.field public static normal:I = 0x7f09011a

.field public static off:I = 0x7f09011e

.field public static on:I = 0x7f09011f

.field public static parentPanel:I = 0x7f090133

.field public static progress_circular:I = 0x7f09013f

.field public static progress_horizontal:I = 0x7f090140

.field public static radio:I = 0x7f090141

.field public static screen:I = 0x7f090150

.field public static scrollIndicatorDown:I = 0x7f090152

.field public static scrollIndicatorUp:I = 0x7f090153

.field public static scrollView:I = 0x7f090154

.field public static search_badge:I = 0x7f090156

.field public static search_bar:I = 0x7f090157

.field public static search_button:I = 0x7f090158

.field public static search_close_btn:I = 0x7f090159

.field public static search_edit_frame:I = 0x7f09015a

.field public static search_go_btn:I = 0x7f09015b

.field public static search_mag_icon:I = 0x7f09015c

.field public static search_plate:I = 0x7f09015d

.field public static search_src_text:I = 0x7f09015e

.field public static search_voice_btn:I = 0x7f09015f

.field public static select_dialog_listview:I = 0x7f090160

.field public static shortcut:I = 0x7f090163

.field public static spacer:I = 0x7f09016e

.field public static split_action_bar:I = 0x7f090171

.field public static src_atop:I = 0x7f090175

.field public static src_in:I = 0x7f090176

.field public static src_over:I = 0x7f090177

.field public static submenuarrow:I = 0x7f090181

.field public static submit_area:I = 0x7f090182

.field public static tabMode:I = 0x7f090183

.field public static textSpacerNoButtons:I = 0x7f090194

.field public static textSpacerNoTitle:I = 0x7f090195

.field public static title:I = 0x7f0901a2

.field public static titleDividerNoCustom:I = 0x7f0901a3

.field public static title_template:I = 0x7f0901a4

.field public static topPanel:I = 0x7f0901a7

.field public static unchecked:I = 0x7f0901b4

.field public static uniform:I = 0x7f0901b5

.field public static up:I = 0x7f0901b7

.field public static wrap_content:I = 0x7f0901c4


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
